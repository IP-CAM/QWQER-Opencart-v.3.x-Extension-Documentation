<?php
// Heading
$_['heading_title'] = 'Deliver by QWQER';

// Text
$_['text_extension']     = 'Extensions';
$_['text_calculate']     = 'Calculate';
$_['text_price_success'] = 'Price calculated';
$_['text_delivery_created_1'] = 'QWQER delivery order successfully created.';
$_['text_delivery_created_2'] = 'Do not forget to change order status to <strong>Shipped</strong> or similar.';
$_['text_delivery_created_3'] = 'Now you can track QWQER delivery order status in order info page.';

// Button
$_['button_ok']     = 'Accept delivery';
$_['button_cancel'] = 'Cancel';

// Entry
$_['entry_pick_up_address']      = 'Pick up address (Your store\'s address)';
$_['entry_delivery_address']     = 'Delivery address (Order shipping address)';
$_['entry_delivery_price']       = 'Delivery price';
$_['entry_store_address']        = 'Store address';
$_['entry_address_country']      = 'Country';
$_['entry_address_countrycode2'] = 'Country code ISO-2';
$_['entry_address_city']         = 'City';
$_['entry_address_citycode2']    = 'City code (2 symbols)';
$_['entry_address_zipcode']      = 'Post code';
$_['entry_address_state']        = 'State';
$_['entry_address_statecode']    = 'State code';
$_['entry_address_region']       = 'Region';
$_['entry_address_regioncode2']  = 'Region code (2 symbols)';
$_['entry_address_address']      = 'Address';

// Error
$_['error_order_id_not_provided']    = 'Order ID is not provided';
$_['error_order_not_exist']          = 'Order not found';
$_['error_sender_address_empty']     = 'Sender address not provided';
$_['error_sender_address_not_found'] = 'Sender address not found';
$_['error_receiver_address_empty']   = 'Receiver address not provided';
