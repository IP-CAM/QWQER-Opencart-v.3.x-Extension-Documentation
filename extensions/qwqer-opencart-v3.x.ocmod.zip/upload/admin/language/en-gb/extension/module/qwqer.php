<?php
// Heading
$_['heading_title'] = 'QWQER Delivery';

// Text
$_['text_extension']     = 'Extensions';
$_['text_edit']          = 'Edit QWQER Delivery Module Settings';
$_['text_success']       = 'Success: You have modified QWQER Delivery module!';
$_['text_signup']        = 'QWQER is a delivery service <a href="https://qwqer.eu/" target="_blank" class="alert-link">signup here</a>.';
$_['text_documentation'] = 'QWQER Delivery extension <a href="https://ipaydevteam.github.io/QWQER-OpenCart-Extension-Documentation/" target="_blank" class="alert-link">documentation here</a>.';

// Button
$_['button_add_additional_address']    = 'Add additional address';
$_['button_remove_additional_address'] = 'Remove additional address';

// Entry
$_['entry_status']               = 'Status';
$_['entry_login']                = 'QWQER Login';
$_['entry_password']             = 'QWQER Password';
$_['entry_store_address']        = 'Store address';
$_['entry_address_country']      = 'Country';
$_['entry_address_countrycode2'] = 'Country code ISO-2';
$_['entry_address_city']         = 'City';
$_['entry_address_citycode2']    = 'City code (2 symbols)';
$_['entry_address_zipcode']      = 'Post code';
$_['entry_address_state']        = 'State';
$_['entry_address_statecode']    = 'State code';
$_['entry_address_region']       = 'Region';
$_['entry_address_regioncode2']  = 'Region code (2 symbols)';
$_['entry_address_address']      = 'Address';

// Error
$_['error_permission']     = 'Warning: You do not have permission to modify QWQER Delivery module!';
$_['error_login']          = 'Login must be present!';
$_['error_password']       = 'Password must be present!';
$_['error_address']        = 'Address must be present!';
$_['error_field_required'] = 'Field is required!';
