<?php

class ControllerExtensionModuleQwqer extends Controller
{
    private $error = array();

    public function index()
    {
        // Preload
        $this->load->language('extension/module/qwqer');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');


        // Form
        $data['form'] = array_merge([
            'module_qwqer_status' => false,
            'module_qwqer_login' => null,
            'module_qwqer_password' => null,
            'module_qwqer_store_addresses' => [
                [
                    'address' => '',
                    'country' => '',
                    'countrycode2' => '',
                    'city' => '',
                    'citycode2' => '',
                    'zipcode' => '',
                    'state' => '',
                    'statecode' => '',
                    'region' => '',
                    'regioncode2' => '',
                ]
            ]
        ], $this->model_setting_setting->getSetting('module_qwqer') ?: [], $this->request->post);


        // Form submitting
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_qwqer', $data['form']);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module'));
        }


        // Warning notification
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }


        // Error login
        if (isset($this->error['login'])) {
            $data['error_login'] = $this->error['login'];
        } else {
            $data['error_login'] = '';
        }


        // Error password
        if (isset($this->error['password'])) {
            $data['error_password'] = $this->error['password'];
        } else {
            $data['error_password'] = '';
        }


        // Error store addresses
        if (isset($this->error['store_addresses'])) {
            $data['error_store_addresses'] = $this->error['store_addresses'];
        } else {
            $data['error_store_addresses'] = [];
        }


        // Breadcrumbs
        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/qwqer', 'user_token=' . $this->session->data['user_token'])
            ]
        ];


        // Actions
        $data['action'] = $this->url->link('extension/module/qwqer', 'user_token=' . $this->session->data['user_token']);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');


        // Layout
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');


        // Response
        $this->response->setOutput($this->load->view('extension/module/qwqer', $data));
    }

    public function validate()
    {
        if (!$this->user->hasPermission('modify', 'extension/module/qwqer')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['module_qwqer_login']) {
            $this->error['login'] = $this->language->get('error_login');
        }

        if (!$this->request->post['module_qwqer_password']) {
            $this->error['password'] = $this->language->get('error_password');
        }


        if (!isset($this->request->post['module_qwqer_store_addresses'])) {
            $this->error['store_addresses'] = [$this->language->get('error_password')];
        } else {
            $this->error['store_addresses'] = [];
            foreach ($this->request->post['module_qwqer_store_addresses'] as $index => $store_address) {
                if (!$store_address['address']) {
                    $this->error['store_addresses'][$index]['address'] = $this->language->get('error_field_required');
                }
                if (!$store_address['country']) {
                    $this->error['store_addresses'][$index]['country'] = $this->language->get('error_field_required');
                }
                if (!$store_address['countrycode2']) {
                    $this->error['store_addresses'][$index]['countrycode2'] = $this->language->get('error_field_required');
                }
                if (!$store_address['city']) {
                    $this->error['store_addresses'][$index]['city'] = $this->language->get('error_field_required');
                }
                if (!$store_address['zipcode']) {
                    $this->error['store_addresses'][$index]['zipcode'] = $this->language->get('error_field_required');
                }
            }

            if (empty($this->error['store_addresses'])) {
                unset($this->error['store_addresses']);
            }
        }

        return !$this->error;
    }
}
