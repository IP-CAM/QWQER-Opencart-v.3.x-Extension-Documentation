<?php

class ControllerExtensionModuleQwqerCreate extends Controller
{
    public function index()
    {
        // Preload
        $this->load->language('extension/module/qwqer/global');
        $this->load->model('extension/module/qwqer/request');
        $this->load->model('extension/module/qwqer');


        // Login to QWQER Api
        try {
            $loginResponse = $this->model_extension_module_qwqer_request->post('/api/xr/mch/login', [
                'login' => $this->config->get('module_qwqer_login'),
                'passw' => $this->config->get('module_qwqer_password')
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }
        $token = $loginResponse['data']['restid'];


        // Delivery order price from QWQER Api
        try {
            $deliveryCreateResponse = $this->model_extension_module_qwqer_request->post('/api/xr/mch/delivery', [
                'distance' => $this->request->post['distance'],
                'dunit' => 'METER',
                'dkind' => 'NONE',
                'country' => $this->request->post['sender']['countrycode2'],
                'duration' => $this->request->post['duration'],
                'summa' => $this ->request->post['price'] - $this->request->post['discount'],
                'sender' => $this->request->post['sender'],
                'receiver' => $this->request->post['receiver'],
                'ordersize' => $this->request->post['ordersize'],
                'status' => 1,
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }


        // Make payment
        try {
            $this->model_extension_module_qwqer_request->post('/api/xr/mch/delivery_payment', [
                'id' => $deliveryCreateResponse['data']['id']
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }


        // Add qwqer order
        $qwqer_order_id = $this->model_extension_module_qwqer->addOrder(
            $this->request->post['order_id'],
            $deliveryCreateResponse['data']['id'],
            $deliveryCreateResponse['data']['status']
        );


        $this->response->setOutput(json_encode(['data' => [
            'qwqer_order_id' => $qwqer_order_id,
            'status_name' => $this->language->get('qwqer_status_name')[(int)$deliveryCreateResponse['data']['status']]
        ]]));
    }
}
