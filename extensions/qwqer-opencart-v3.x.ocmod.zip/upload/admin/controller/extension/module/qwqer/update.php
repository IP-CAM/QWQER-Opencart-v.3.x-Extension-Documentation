<?php

class ControllerExtensionModuleQwqerUpdate extends Controller
{
    public function index()
    {
        // Preload
        $this->load->language('extension/module/qwqer/global');
        $this->load->language('extension/module/qwqer/modal');
        $this->load->model('extension/module/qwqer/request');
        $this->load->model('extension/module/qwqer');


        // Validate order id
        if (!isset($this->request->get['order_id'])) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_order_id_not_provided')]));

            return;
        }
        $order_id = $this->request->get['order_id'];


        // Check QWQER order entry
        $qwqer_order = $this->model_extension_module_qwqer->getOrderByOrderId($order_id);
        if (!$qwqer_order) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_order_not_exist')]));

            return;
        }


        // Login to QWQER Api
        try {
            $loginResponse = $this->model_extension_module_qwqer_request->post('/api/xr/mch/login', [
                'login' => $this->config->get('module_qwqer_login'),
                'passw' => $this->config->get('module_qwqer_password')
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }
        $token = $loginResponse['data']['restid'];


        // Delivery order price from QWQER Api
        try {
            $deliveryStatusResponse = $this->model_extension_module_qwqer_request->get('/api/xr/mch/delivery/' . $qwqer_order['qwqer_id'], [], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }


        // Update status
        $this->model_extension_module_qwqer->updateStatus($qwqer_order['id'], $deliveryStatusResponse['data']['status']);


        $this->response->setOutput(json_encode(['data' => [
            'status_name' => $this->language->get('qwqer_status_name')[$deliveryStatusResponse['data']['status']]
        ]]));
    }
}
